#!/bin/sh
#This script installs wordpress

apt-get update
apt-get install -y wordpress